To run  the program, first put the cap file into the same directory as the python program file, then run the following command in command line:
python3 TrafficAnalysis.py <your-cap-file>.cap